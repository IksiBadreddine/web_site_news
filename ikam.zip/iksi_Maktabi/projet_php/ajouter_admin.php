<?php
    require 'connexion.php';

    if(isset($_POST['ajouter_admin'])){
        $adminusername = $_POST['admin_username'];
        $nomAdmin = $_POST['nom_admin'];
        $prenomAdmin = $_POST['prenom_admin'];
        $emailAdmin = $_POST['email_admin'];
        $mdpAdmin = $_POST['mdp_admin'];

        $sql = "INSERT INTO admins (admin_username,nom_admin, prenom_admin, email_admin, mdp_admin) VALUES ('$adminusername','$nomAdmin', '$prenomAdmin', '$emailAdmin', '$mdpAdmin')";
        $query = mysqli_query($con, $sql);

        if($query){
            $message = "Admin ajouté avec succès.";
            echo "<script>alert('" . $message . "'); window.location.href ='http://localhost/projet_php/admin.php';</script>"; 
        } else {
            $message = "Admin ajouté avec succès.";
            echo "<script>alert('" . $message . "'); window.location.href ='http://localhost/projet_php/admin.php';</script>"; 
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="layout/styles/ajouter_ad.css">
    <title>IkamAd.News</title>
</head>
<body>
    <!--header-->
    <div class="header"> 
        <div class="logo">
            <a href="#">IKAM.NEWS</a>
        </div>
        <nav>
            <ul>
                <li><a href="http://localhost/projet_php/ikam.php">Home</a></li>
                
            </ul>
           
        </nav>
    </div>

    <!--ajout-->
    <div class="loginbox">
        <form class="loginform" method="POST" action="ajouter_admin.php">
            <h2 class="h2">Ajouter un administrateur<h2>
            <label class="labels" for="admin_username">Username:</label>
            <input type="name" name="admin_username">
            <label class="labels" for="nom_admin">Nom:</label>
            <input type="name" name="nom_admin">
            <label class="labels" for="prenom_admin">Prénom:</label>
            <input type="name" name="prenom_admin">
            <label class="labels" for="email_admin">Email:</label>
            <input type="email" name="email_admin">
            <label class="labels" for="mdp_admin">Mot de passe:</label>
            <input type="password" name="mdp_admin">
            <input class="ajouter" type="submit" name="ajouter_admin" value="Ajouter">
        </form>
    </div>
    
</body>
</html>
