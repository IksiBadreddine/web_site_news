<?php
//Importation du code de connexion à la base de données
require'connexion.php';

//Vérification de la connexion
if (mysqli_connect_errno()) {
    echo "Échec de la connexion à la base de données: " . mysqli_connect_error();
    exit();
}
//Requête pour retrouver les noms de tous les admins
$sql = 'SELECT admin_username FROM admins';

//Exécution de la requête
$result = mysqli_query($con, $sql);

//Vérification des erreurs de requête
if (!$result) {
    echo "Erreur de requête: " . mysqli_error($con);
    exit();
}

//Récupération des données dans un tableau $admins
$admins = array();
while ($row = mysqli_fetch_assoc($result)) {
    $admins[] = $row['admin_username'];
}

//Requête pour retrouver toutes les catégories
$sql = 'SELECT * FROM categorie';

//Exécution de la requête
$result = mysqli_query($con, $sql);

//Vérification des erreurs de requête
if (!$result) {
    echo "Erreur de requête: " . mysqli_error($con);
    exit();
}

//Récupération des données dans un tableau $categories
$categories = array();
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row;
}

//Fermeture de la connexion à la base de données
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOUVEAU ARTICLE</title>
    
    <style>
        body {
            background-color: #1F163B;
            color: #C0B5E3;
            font-family: Arial, sans-serif;
        }

        form {
            margin: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            background-color: #2F2259;
            color: #C0B5E3;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #2F2259;
            color: #C0B5E3;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form action="saveArticle.php" method="post" enctype="multipart/form-data">
        <div class="input-groupe">
            <label for="">Titre</label>
            <input type="text" name="titre_article" id="titre">
        </div>

        <div class="input-groupe">
            <label for="">Contenu</label>
            <input type="text" name="contenu_article" id="contenu">
        </div>

        <div class="input-groupe">
            <label for="">Administrateur</label>
            <select name="editeur">
                
                <?php
                //Affichage de chaque administrateur dans la liste SELECT
                if ($admins) {
                    foreach ($admins as $admin) {
                        echo '<option value="' . $admin . '">' . $admin . '</option>';
                    }
                }
                ?>
            </select>
        </div>

        <div class="input-groupe">
            <label for="">Catégorie</label>
            <select name = "categorie">
                <?php
                //Affichage da chaque catégorie dans la liste
                if ($categories) {
                    foreach ($categories as $categorie) {
                        echo '<option value="' . $categorie['id_categorie'] .'">' . $categorie['nom_categorie'] . '</option>';
                    }
                }
                ?>
            </select>
        </div>

        <div class="input-groupe">
            <label for="imageToUpload">Importer image</label>
            <input type="file" name="imageToUpload" id="image">
        </div>

        <div class="input-groupe">
            <input type="submit" value="Enregistrer" name="Enregistrer">
        </div>
    </form>
</body>
</html>