<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="layout/styles/l.css">
    <title>IkamLogin.News</title>
</head>
<body>
    <!--header-->
<div class="wrapper col1">
    <div id="header"> 
        <div id="logo">
            <h1><a href="#"><i>IKAM.NEWS</i> </a></h1> 
        </div>
        <div id="topnav">
            
            <ul class="ul">
                <li><a href="http://localhost/projet_php/ikam.php">Home</a></li>
                <li><a href="http://localhost/projet_php/signup.php">Signup</a></li>
            </ul>   
        
        </div>

        <br class="clear" />
    </div>
</div>

    <div class="loginbox">
    <form class="loginform" method="POST" action="traitementad.php">
         <h2 class="h2">Login</h2>
                <label class="labels">Email</label>
                <input type="email" name="email" placeholder="Enter your Email...">
                <label class="labels">Password</label>
                <input type="password" name="password" placeholder="Enter your Password...">
                 <button type="submit">Login</button>
                <div class="signin">
                    <p>New User?  <a class="lien" href="http://localhost/projet_php//signup.php"> SignUp here!</a></p>
                </div>
                    
    </form>
        
    </div>







    












    <!----footer--->
<footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>About</h3>
                <p>IKAM.NEWS Website is an online platform dedicated to providing the latest news and information in various fields.</p>
            </div>
            <div class="footer-section">
                <h3>Links</h3>
                <ul class="footer-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Categories</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <ul class="footer-contact">
                    <li><i class="fas fa-envelope"></i>Ikam49@gmail.com</li>
                    <li><i class="fas fa-phone"></i>05-22-00-00-00</li>
                    <li><i class="fas fa-map-marker"></i> Morocco-Safi</li>
                </ul>
            </div>
        </div>
        
    </footer>
    
</body>
</html>
