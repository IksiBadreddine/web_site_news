-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 04 juin 2023 à 01:29
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ikam_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `admin_username` varchar(20) NOT NULL,
  `nom_admin` varchar(50) NOT NULL,
  `prenom_admin` varchar(20) NOT NULL,
  `email_admin` varchar(50) NOT NULL,
  `mdp_admin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`admin_username`, `nom_admin`, `prenom_admin`, `email_admin`, `mdp_admin`) VALUES
('iksibadr', 'iksi', 'badr', 'iksibadr4@gmail.com', 'iksi'),
('sarah', 'Maktabiiii', 'Sara', 'Saramaktabi9@gmail.com', 'maktabiii');

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id_article` int(10) NOT NULL,
  `titre_article` varchar(255) NOT NULL,
  `image_article` varchar(255) NOT NULL,
  `contenu_article` varchar(2000) NOT NULL,
  `id_categorie` int(10) NOT NULL,
  `admin_username` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id_article`, `titre_article`, `image_article`, `contenu_article`, `id_categorie`, `admin_username`) VALUES
(1, 'Running out of battery: how post-Brexit Britain is failing to set up a future-focused economy | Mariana Mazzucato', '4.jpg', 'LyrArc Article Gist\r\nA professor of economics of innovation and public value at University College, London, says one-off deals such as the one with Land Rover to produce electric car batteries is not an adequate response to the big industrial strategies of the US and the European Union. Mariana Mazzucato says in this Guardian article the UK\'s decision to leave the EU is costing 100 billion pounds in output. Of 100 leading Uk manufacturers about half say their suppliers in the EU are more cautious about doing business in the UK. She compares the US industrial strategy that combines public and private investment of $3.5 trillion over the next decade, and the EU\'s for $2 trillion with Britain\'s effort. She says of the UK that it has nothing like this and worse with austerity it is moving in the opposite direction. Another problem is the change in governments of the Tories and new industrial policy every time there is a new minister.\r\n\r\nBusiness investment in UK is 19% less than the G7 average. The civil service needs investment, as she says Britain has become addicted to outsourcing the core functions of the public sector. Mazzucato says the government for aid to the private sector should do what Germany and France have done to expect reduction in carbon emissions, or as the US has done with Biden\'s Chips Act of giving aid given that there are no share buybacks by companies.', 1, 'sarah'),
(2, 'G.O.P. Revolts Over Debt Limit Deal as Bill Moves Toward a House Vote', '5.jpg', 'LyrArc Article Gist\r\nThe debt ceiling agreement between Biden and McCarthy has made it out of the committee stage and now heads to the House floor. Both Biden and McCarty are confident it will pass quickly before June 5. There are some surprises as the the impact of the debt ceiling agreement is better understood. 78,000 additional people will get food aid costing an additional $2 billion as a result of the tighter work requirements for the food aid program. The program will make it easier for veterans and homeless people to get benefits. \r\n\r\nThe cuts to the IRS funding by about $21 billion will be used by the Biden adminstration to reduce the effects of other cuts in programs that help people struggling with the cost of living. \r\n\r\nOn defense spending Biden says \"obviously if there is an existential need for additional spending I have no doubt we will be able to get it.\"\r\n\r\nBoth sides say this agreement is the best that could be done for either side. \"With divided government they get to have an opinion, and we get to have an opinion, and all things equal, I think a compromise agreement is reasonable for both sides,\" says Shalanda Young, Mr. Biden\'s negotiator and Budget Office Director. Congressional Budget Office estimate is for $1.5 trillion in debt reduction over a decade.', 1, 'sarah'),
(3, 'House to vote on debt limit deal as lawmakers race to avert default', '6.jpg', 'The House of Representatives is on track to vote Wednesday on a bill to suspend the nation’s debt limit through January 1, 2025, as lawmakers race to prevent a catastrophic default.\r\n\r\nIf the House passes the bill as expected, it would next need to be passed by the Senate before it can be sent to President Joe Biden to be signed into law. In the Senate, any one lawmaker can delay a swift vote and Senate Majority Leader Chuck Schumer has told lawmakers to prepare for the possibility of votes Friday or over the weekend.\r\n\r\nThe timeframe to pass the bill through Congress is extremely tight and there is little room for error, putting enormous pressure on leadership in both parties.\r\n\r\nLawmakers are racing the clock to avert a first-ever default ahead of June 5, the date the Treasury Department has said it will no longer be able to pay all of the nation’s obligations in full and on time, a scenario that could trigger global economic catastrophe.\r\n\r\nThe bipartisan debt limit deal struck between the White House and House Republicans was announced over the weekend – the culmination of long days and late nights of contentious negotiations that at times looked like they might breakdown and fall apart entirely.\r\n\r\nThe effort to secure a debt limit deal has proven to be a major leadership test for both House Speaker Kevin McCarthy and Biden.\r\n\r\n', 1, 'iksibadr'),
(4, 'The debt ceiling is an awkward place to talk about spending', '7.jpg', 'The debt ceiling snafu, which has the potential to wreck the US economy, is a civics lesson in the bizarrely inefficient way the American government spends your money.\r\n\r\nHere’s the broadest outline of how members of Congress oversee trillions in tax dollars each year and the borrowing of money to make up for the annual shortfall:\r\n\r\nThey budget. Lawmakers debate and set priorities through a detailed budget process that was created in the 1970s. The White House initiates a budget proposal each year, and a set of budget committees take a look.\r\nThey authorize. A different set of committees votes to give the government authority to set up and run government programs.\r\nThey appropriate. A third set of committees actually OKs the spending of money, effectively telling the Treasury Department to cut checks.\r\nThey reconcile. Congress OKs the spending of more money than it brings in every year, so the budget process gives lawmakers an opportunity to bypass normal rules to address deficits. (Although in recent years, Republican lawmakers have used this special reconciliation process to pass massive permanent tax cuts for corporations, and Democrats have used it to fund new spending.)', 1, 'iksibadr'),
(5, 'Fact checking Trump’s claims about January 6 during CNN’s townhall', '8.jpg', 'Trump asserted “a couple” of the January 6 rioters “probably got out of control,” comparing the insurrection to left-leaning protests that turned violent in other cities.\r\n\r\nFacts First: This statement is false. Hundreds of rioters have been charged with violence toward police on January 6 and Trump downplaying the violence and equivocating the insurrection with social justice protests fails to recognize the severity of the attack on the Capitol.\r\n\r\nThe January 6 riot of Trump-supporters who overran the Capitol has resulted in the largest law enforcement response in modern history – because of the sheer amount of violence on the ground, especially toward police, that day.\r\n\r\nThe number of rioters on January 6 who’ve been charged with violence toward police is in the hundreds.\r\n\r\nAccording to the Justice Department this week, 346 people face federal charges for assaulting, resisting or impeding officers or other employees. That includes more than 100 people charged with using a weapon or causing serious injury to an officer. About five dozen have pleaded guilty to felony charges for these types of crimes.', 1, 'sarah'),
(6, 'McCarthy’s secret speaker deal takes a bizarre turn', '9.jpg', 'This post has been updated with the Rules Committee vote.\r\n\r\nWe knew the House was liable to get messy when Republicans took it over and Kevin McCarthy needed to cut a mysterious agreement with the right-wing House Freedom Caucus to become speaker.\r\n\r\nWhat we might not have fully appreciated at the time is how much that mess might result from not being able to agree on what the agreement was.\r\n\r\nThe first big hurdle for the debt ceiling deal McCarthy (R-Calif.) cut with President Biden over the weekend was the all-important House Rules Committee on Tuesday afternoon. This committee can make or break legislation, which is why the Freedom Caucus was keen to pry three seats from the speaker loyalists that usually inhabit it. That left McCarthy with only six such votes on a 13-member committee, shy of a majority of his allies.', 1, 'sarah'),
(7, 'Giant plume spotted erupting from moon of Saturn might contain ingredients for life', '10.jpg', 'NASA’s JWST space telescope has observed a 10,000-kilometer-long plume of water vapor jetting into space from Saturn’s moon Enceladus—the largest spray ever detected from the icy world, which is just one-seventh the diameter of Earth’s Moon.\r\n\r\nPlanetary scientists view Enceladus as a prime target in the search for extraterrestrial life because beneath its icy crust the moon houses a salty ocean—a good medium for the ingredients of life to mix. Vented from fractures in the crust, the towering plume might saturate the Saturn system with some of the chemicals needed for life. Researchers describe the results today in a NASA press release and in a paper accepted at Nature Astronomy.\r\n\r\n“It’s staggering to have such a huge plume from such a small object,” says Christopher Parkinson, a planetary scientist at the California Institute of Technology who was not part of the JWST study.', 2, 'sarah'),
(8, 'Move to change how U.S. tracks pesticide use sparks protest', '11.jpg', 'Last year, Alan Kolok, an ecotoxicologist at the University of Idaho, published a study that found the incidence of cancer in counties across 11 western U.S. states was correlated with the use of farm chemicals called fumigants, which kill soil pests. The fine-grained analysis was feasible, he says, because a U.S. government database made timely, county-level statistics on pesticide use publicly available.\r\n\r\nNow, Kolok is one of many scientists concerned that changes to the National Pesticide Use Maps database will make it far less useful to scientists. Last month, he joined more than 250 researchers and dozens of public health and environmental groups in urging the U.S. Geological Survey (USGS), which oversees the database, to reconsider moves to reduce the number of chemicals it tracks and to release updates less frequently.\r\n\r\nThe agency says the changes are being driven, in part, by budget constraints and a desire to align the pesticide survey with its other research programs. But in an open letter to USGS, critics say the changes endanger a database that provides “vital information and tracks trends that are not available anywhere else.”\r\nThe USGS data have played a role in more than 500 peer-reviewed studies, the letter notes, including highly cited works on the impact of pesticides on public health, water quality, and ecosystems. Instead of reducing the database’s scope and frequency, the critics say USGS should be expanding it in order better track the estimated 540 million kilograms of pesticides used annually in the United States. “We need credible sources of data to be able to study and understand what this widespread pesticide use means to the health of people and the environment,” the letter states.\r\n\r\nAt its height, the USGS database, which dates to 1992, tracked the shifting use of more than 400 chemicals to control insects, fungi, weeds, and other pests. Each year, the agency typically released preliminary maps documenting pesticide use\r\n2 years pri', 2, 'iksibadr'),
(9, 'The COVID-19 virus mutated to outsmart key antibody treatments. Better ones are coming', '12.jpg', 'In 2020, as the COVID-19 pandemic raged and other effective drugs were elusive, monoclonal antibodies (mAbs) emerged as a lifesaving treatment. But now, 3 years later, all the approvals for COVID-19–fighting antibodies have been rescinded in the United States, as mutations of the SARS-CoV-2 virus have left the drugs—which target parts of the original virus—ineffective.\r\n\r\nResearchers around the globe are now trying to revive antibody treatments by redesigning them to take aim at targets that are less prone to mutation. “There are new approaches that present a much more challenging task for the virus to evade,” says Paul Bieniasz, a virologist at Rockefeller University. Just this week, for example, researchers in Canada reported that they’ve created antibodylike compounds able to grab dozens of sites on viral proteins at the same time, acting as a sort of molecular Velcro to restrain the virus even if some of the sites have mutated to elude the drug candidate. Other researchers have taken less radical approaches to producing mutation-resistant antibodies.\r\n\r\nAll, however, worry that the work may be slow to reach the clinic. With the pandemic emergency declared over in the U.S. and other countries, governments and industry may have less incentive to develop promising new COVID-19 treatments. “There is no business model for this anymore,” says Michael Osterholm, a public health expert at the University of Minnesota.', 2, 'sarah'),
(10, 'Humans might be able to hibernate during space travel', '13.jpg', 'A teenager joins a line of people boarding a spaceship. Once on board, she approaches a bed, crawls in, closes the lid and falls asleep. Her body is frozen for a trip to a planet several light-years from Earth. A few years later she wakes up, still the same age. This ability to put her life on pause while asleep is called “suspended animation.”\r\n\r\nScenes like this are a staple of science fiction. There’s plenty of other ways that suspended animation has touched our imagination, too. There’s Captain America, for instance, who survived nearly 70 years frozen in ice. And Han Solo was frozen in carbonite in Star Wars: The Empire Strikes Back. The Mandalorian’s main character brings in some of his bounties cold, too.\r\n\r\nAll of these stories have something in common. People enter an unconscious state in which they can survive for a long time.\r\n\r\nNothing like this is yet possible in the real world, at least for us humans. But some animals and birds have their own forms of suspended animation: They hibernate. This might hold some lessons for how to put astronauts of the future into hibernation for long space flights. But for really long journeys, a deep freeze might be the best option.', 2, 'sarah'),
(11, 'Analyze This: Plants sound off when they’re in trouble', '14.jpg', 'Thirsty tomato and tobacco plants make clicking sounds, researchers have found. The sounds are ultrasonic, meaning they are too high-pitched for human ears to hear. But when the noises are converted to lower pitches, they sound like popping bubble wrap. Plants also make clicks when their stems are cut.\r\n\r\nIt’s not like the plants are screaming, Lilach Hadany tells Science News. An evolutionary biologist, she works at Tel Aviv University in Israel. Plants may not mean to make these noises, she says. “We’ve shown only that plants emit informative sounds.”\r\n\r\nHadany and her colleagues first heard the clicks when they set microphones next to plants on tables in a lab. The mics caught some noises. But the researchers needed to make sure that the clicking was coming from the plants.\r\n\r\nSo, the scientists placed plants inside soundproofed boxes in the basement, far from the hubbub of the lab. There, microphones picked up ultrasonic pops from thirsty tomato plants. Though it was outside humans’ hearing range, the racket made by plants was about as loud as a normal conversation.\r\n\r\nSnipped tomato plants and dry or cut tobacco plants clicked, too. But plants that had enough water or hadn’t been snipped stayed mostly quiet. Wheat, corn, grapevines and cacti also babbled when stressed out. These findings appeared March 30 in Cell.', 2, 'iksibadr'),
(12, 'One collision could have formed the moon and started plate tectonics', '15.jpg', 'THE WOODLANDS, TEXAS — Our moon is thought to have formed when a Mars-sized planet called Theia slammed into early Earth. That smashup would have kicked a cloud of debris into space that later clumped together to form the moon. Now, computer models suggest that bits of Theia left deep inside Earth could have kick-started plate tectonics. That’s the continual shuffling of pieces of Earth’s surface.\r\n\r\nQian Yuan shared this idea March 13 at the Lunar and Planetary Science Conference. Yuan studies how the inner layers of Earth move and affect the surface at Caltech in Pasadena, Calif. His team’s research offers a neat explanation for how Earth got both its moon and its moving plates. If it’s true, that knowledge could help astronomers spot Earthlike worlds around other stars. But some scientists caution that it’s way too early to say that this is, in fact, what happened to Earth.\r\nOf all the worlds discovered so far, ours is the only one known to have plate tectonics. For billions of years, Earth’s creeping plates have spread, collided and plunged beneath one another. This motion has birthed and split continents. It has pushed up mountain ranges. And it has widened oceans. But all this reshaping has also erased most of the planet’s early history. That includes how and when plate tectonics first began.\r\n\r\nTo answer this question, Yuan and his colleagues focused on two continent-sized blobs of material in Earth’s lower mantle. Some scientists think these regions formed from old tectonic plates that slipped deep down into Earth. But Yuan’s team thought the mysterious masses could instead be the dense, sunken remnants of Theia. So, the team built computer models of this scenario. The models showed how Theia’s impact and sunken remains would affect the flow of rock inside Earth.', 2, 'iksibadr'),
(13, 'Cyclisme : le Slovène Primoz Roglic remporte son premier Tour d\'Italie', '16.jpg', 'Un triomphe au goût de revanche au pied du Colisée. Le Slovène Primoz Roglic a remporté, dimanche 28 mai, son premier Tour d\'Italie dans les rues de Rome. Au sprint, c\'est Mark Cavendish qui a remporté la 21e et dernière étape du Giro.\r\n\r\nIvre de bonheur, Primoz Roglic a savouré une victoire ayant valeur de rédemption, trois ans après son échec traumatique sur le Tour de France.\r\n\r\nC\'est la quatrième victoire dans un grand Tour pour le coureur de Jumbo-Visma après ses trois succès sur le Tour d\'Espagne. Il devance pour seulement quatorze secondes au classement général le Britannique Geraint Thomas, très digne dans la défaite et poisson-pilote de luxe dimanche pour emmener son compatriote Mark Cavendish à une dix-septième victoire dans le Giro.\r\n\r\n\"C\'était super incroyable\"\r\nPour Roglic, 33 ans, ce triomphe romain a une saveur très particulière, trois ans après avoir vécu un cauchemar dans le Tour de France lorsque, maillot jaune depuis onze jours, il avait été renversé par Tadej Pogacar lors d\'un contre-la-montre tragique à la veille de l\'arrivée.\r\n\r\nLa revanche est d\'autant plus douce qu\'il a vécu cette fois le scénario à l\'envers. Il a pris le pouvoir sur le Giro samedi en détroussant le Gallois Geraint Thomas de son maillot rose sur un dernier chrono en côte dans l\'effrayant Monte Lussari, devant des milliers de supporters slovènes en transe. Dont – incroyable clin d\'œil du destin – un de ses anciens coéquipiers de l\'équipe nationale juniors de saut à ski, Mitja Meznar, qui se trouvait par hasard pile à l\'endroit où il a connu un saut de chaîne et qui l\'a aidé à repartir.\r\n\r\n\"Les émotions que j\'ai vécues hier sur le Monte Lussari resteront gravées à vie. Je n\'oublierai jamais. C\'était super incroyable\", a insisté Roglic.', 3, 'sarah'),
(14, 'Lionel Messi: From shy genius to \'bad boy\' leader – his Qatar transformation', '17.jpg', 'When Lionel Messi won the World Cup at the fifth and, seemingly, final attempt in Qatar last December, it was the last jigsaw piece in arguably the greatest footballing CV of all time.\r\n\r\nBut victory was only part of the story.\r\n\r\nBehind the scenes and then on the biggest stage, Messi\'s transformation in the Middle East became evident.\r\n\r\nThe 35-year-old\'s genius has long been beyond doubt and debate. But his character had changed. As a teenager, Messi was so painfully shy he would get changed in the corridor to avoid his team-mates in the Barcelona youth set-up.\r\n\r\n\"This World Cup he was different,\" said Argentina and Aston Villa goalkeeper Emiliano Martinez.\r\n\r\nWATCH: Lionel Messi: Destiny\r\n\"We are probably more aggressive than the players in the national teams he\'s played with before. So he\'s probably becoming a little more like us - that bad boy.\"\r\n\r\nHere, some of the stars from the recently-released BBC Sport documentary Lionel Messi: Destiny, unpack and dissect that final evolution of Messi - from shy teenage genius to talismanic \"bad boy\".\r\n\r\nShort presentational grey line\r\n\"He\'s a great lad but he can\'t even direct traffic. How can you give the national team to Scaloni?\"\r\n\r\nDiego Maradona\'s typically colourful thoughts regarding Lionel Scaloni\'s appointment to the Argentina manager job in 2018 captured the mood of the nation.', 3, 'iksibadr'),
(15, 'Mikel Arteta: The rejection and determination that made a manager', '18.jpg', 'A broad smile unfolds across Pepe Reina\'s bronzed features as he recalls the injustice served up to Mikel Arteta in the dorm room of a Barcelona farmhouse they used to call home.\r\n\r\nReina was on the top bunk and Arteta below - but there was no doubt where the noise was coming from.\r\n\r\n\"I was the one snoring and the other lads in the room were getting upset,\" explains the former Liverpool and Napoli goalkeeper.\r\n\r\n\"So they started to throw shinpads, shoes, flip-flops... anything they could lay their hands on.\r\n\r\n\"But because I was on top and he was on the bottom many of them ended up hitting Mikel. The sharing of that bed cost him many sleepless nights and almost our relationship!\"\r\n\r\nPlucked from Madrid and San Sebastian respectively as some of the brightest young talents in Spain, Reina and Arteta left home in their mid-teens to join La Masia. FC Barcelona\'s world-famous residential academy has produced Lionel Messi, Xavi and Andres Iniesta and, until 2011, was located in a stone farmhouse across the road from the Nou Camp, the club\'s iconic stadium.', 3, 'iksibadr'),
(16, 'Aaron Gordon en mission défensive sur Jimmy Butler', '19.jpg', 'Kevin Durant, LeBron James, Karl-Anthony Towns… Depuis le début des playoffs, Aaron Gordon se coltine en défense certains des meilleurs attaquants de la ligue. Un autre défi l’attend aujourd’hui en finale NBA face au Heat : Jimmy Butler.\r\n\r\n« Jimmy est difficile à couvrir pour différentes raisons que les gars que j\'ai gardés dans le passé comme KD et LeBron, KAT. Jimmy fait tout. Il fait toutes les choses intangibles. Il joue en transition, fait des coupes, prend des rebonds offensifs, joue en \'backdoor\' », énumère le coéquipier de Nikola Jokic.\r\n\r\nSera-t-il en mesure de limiter l’impact offensif du leader du Heat qui tourne à 28,5 points de moyenne depuis le début des playoffs ? « Je ne me fixe pas vraiment d\'objectifs en matière de points, rétorque l’ailier des Nuggets. Je veux juste lui rendre la tâche aussi difficile que possible tout au long de la soirée, pendant 48 minutes, pendant toute une série. Faire en sorte que tout ce qu\'il obtient soit difficile. Le faire travailler pour tout. »\r\n\r\nIl ajoute : « Ce n\'est pas du un contre un. Le basket se joue à cinq contre cinq, et il y aura une défense à cinq sur le terrain. » Son propos rappelle ceux tenus par son coach, Mike Malone, quelques jours plus tôt : « On n’arrête pas un gars comme Jimmy Butler avec un seul joueur. Ce ne sera pas seulement la responsabilité d’Aaron Gordon, de Michael Porter Jr ou de celui qui défendra sur lui. […] Ça doit être cinq gars qui défendent comme un seul homme pour essayer d’arrêter un tel talent. Il faut lui proposer différents ‘match-ups’, le perturber, et faire en sorte que les cinq joueurs se concentrent sur cette tâche, une possession à la fois. »', 3, 'iksibadr'),
(17, 'Lionel Messi wins The Best FIFA Men\'s Player award', '20.jpg', 'Lionel Messi has been crowned The Best FIFA Men’s Player 2022.\r\n\r\nThe Argentina and Paris St Germain superstar has been bestowed with the honour following a landmark year in which he inspired his nation to FIFA World Cup™ glory. Messi was presented with the prize at The Best FIFA Football Awards™ ceremony in Paris, having come out on top in the voting ahead of finalists Kylian Mbappe and Karim Benzema.\r\n\r\nThe award was voted for by national team coaches and captains as well as expert journalists and supporters across the globe. Messi also won 2019 Best FIFA Men\'s Player award and becomes the third player to receive the accolade twice, after Cristiano Ronaldo and Robert Lewandowski.\r\nMessi produced a series of mesmeric performances during Argentina\'s triumphant World Cup campaign. The genius number 10 was Argentina’s talisman in Qatar, scoring seven goals – including a brace in that unforgettable final win over France – and providing three assists during the tournament. His stirring leadership was also frequently cited by team-mates as an integral factor in their success. Messi’s inspirational influence was underlined when he was awarded the Golden Ball prize for the competition’s best player. Messi, who also won the accolade at Brazil 2014™, became the first player to receive the honour twice. The attacker also overtook German legend Lothar Matthaus as the World Cup’s record appearance holder.\r\n\r\nAt club level, Messi swiftly settled into life with Paris St Germain after leaving Barcelona in summer 2021. He was a key figure as PSG won the Ligue 1 title in his debut season and has continued to provide regular game-changing contributions for the French side in 2022/23. Messi’s World Cup triumph defined his year, however, as he lit up the game’s grandest stage and lifted the trophy he coveted above all others.', 3, 'sarah'),
(18, 'TV fraud gang jailed for illegally streaming Premier League games', '21.jpg', 'Five men who illegally streamed Premier League football matches to tens of thousands of people have been jailed.\r\n\r\nThe gang sold cut-price £10-a-month subscriptions, bragging they made money showing games not otherwise available to watch live in the UK because of \"blackout\" broadcasting rules.\r\n\r\nTheir operation, described as the biggest so far, received more than £7m from 50,000 subscribers.\r\n\r\nThe sentencing follows a rare private prosecution by the Premier League.\r\n\r\nThe fraud prosecution was brought to protect \"some of the world\'s most valuable content\", the league\'s lawyers said.\r\n\r\nIt followed a lengthy trading-standards investigation led by Hammersmith and Fulham Council.\r\n\r\nAnd the personal details of many of those who paid for Flawless TV are now in the hands of investigators, raising the question of what action might be taken against them.', 3, 'sarah');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `nom_categorie` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `nom_categorie`) VALUES
(1, 'politics'),
(2, 'sciences'),
(3, 'sports');

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE `commentaires` (
  `id_commentaire` int(10) NOT NULL,
  `contenu_commentaire` varchar(1000) NOT NULL,
  `id_article` int(11) NOT NULL,
  `id_visiteur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commentaires`
--

INSERT INTO `commentaires` (`id_commentaire`, `contenu_commentaire`, `id_article`, `id_visiteur`) VALUES
(69, 'essai', 6, 1),
(70, 'test', 6, 1),
(71, 'test', 9, 1),
(73, 'cc', 4, 1),
(74, 'test', 11, 1),
(75, 'test', 17, 1),
(76, 'cc', 6, 1),
(77, 'commentaire ', 5, 1);

-- --------------------------------------------------------

--
-- Structure de la table `visiteurs`
--

CREATE TABLE `visiteurs` (
  `id_visiteur` int(10) NOT NULL,
  `nom_visiteur` varchar(20) NOT NULL,
  `prenom_visiteur` varchar(20) NOT NULL,
  `email_visiteur` varchar(50) NOT NULL,
  `mdp_visiteur` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `visiteurs`
--

INSERT INTO `visiteurs` (`id_visiteur`, `nom_visiteur`, `prenom_visiteur`, `email_visiteur`, `mdp_visiteur`, `username`) VALUES
(1, 'maktabi', 'sara', 'sara@gmail.com', 'sss', 'sarass');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_username`),
  ADD UNIQUE KEY `username` (`admin_username`);

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id_article`),
  ADD KEY `id_categorie` (`id_categorie`),
  ADD KEY `fk_admin` (`admin_username`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD PRIMARY KEY (`id_commentaire`),
  ADD KEY `fk_visteur` (`id_visiteur`),
  ADD KEY `fk_article` (`id_article`);

--
-- Index pour la table `visiteurs`
--
ALTER TABLE `visiteurs`
  ADD PRIMARY KEY (`id_visiteur`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id_article` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `commentaires`
--
ALTER TABLE `commentaires`
  MODIFY `id_commentaire` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT pour la table `visiteurs`
--
ALTER TABLE `visiteurs`
  MODIFY `id_visiteur` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`admin_username`) REFERENCES `admins` (`admin_username`),
  ADD CONSTRAINT `id_categorie` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD CONSTRAINT `fk_article` FOREIGN KEY (`id_article`) REFERENCES `articles` (`id_article`),
  ADD CONSTRAINT `fk_visteur` FOREIGN KEY (`id_visiteur`) REFERENCES `visiteurs` (`id_visiteur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
