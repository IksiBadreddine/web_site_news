<?php
session_start();
require 'connexion.php';

$email = $_POST['email'];
$password = $_POST['password'];
$queryAdmins = "SELECT * FROM admins WHERE email_admin = '$email' AND mdp_admin = '$password'";
$queryVisiteurs = "SELECT * FROM visiteurs WHERE email_visiteur = '$email' AND mdp_visiteur = '$password'";

$resultad = mysqli_query($con, $queryAdmins);
$resultvi = mysqli_query($con, $queryVisiteurs);
$countad = mysqli_num_rows($resultad);
$countvi = mysqli_num_rows($resultvi);

if ($countad > 0) {
    header("Location: http://localhost/projet_php/admin.php");
    exit();
} elseif ($countvi > 0) {
    $row = mysqli_fetch_assoc($resultvi);
    $id_visiteur = $row['id_visiteur'];

    $_SESSION['id_visiteur'] = $id_visiteur;

    header("Location: http://localhost/projet_php/articles.php");
    exit();
} else {
    
    // Afficher le message d'erreur dans une alerte et recharger la page
    $messageErreur = "Veuillez vous inscrire ou vérifier vos informations de connexion.";
    echo "<script>alert('" . $messageErreur . "'); window.location.href ='http://localhost/projet_php/login.php';</script>";



}
?>
