<?php
session_start();
require 'connexion.php';

if(isset($_POST['id_article']) && isset($_POST['commentaire'])) {
    $id_article = $_POST['id_article'];
    $commentaire = $_POST['commentaire'];
    $id_visiteur = $_SESSION['id_visiteur'];

    // Vérifier si l'article existe avant d'insérer le commentaire
    $checkArticleQuery = "SELECT * FROM articles WHERE id_article = '$id_article'";
    $checkArticleResult = mysqli_query($con, $checkArticleQuery);

    if (mysqli_num_rows($checkArticleResult) > 0) {
        // Insérer le commentaire dans la base de données
        $insertQuery = "INSERT INTO commentaires (id_article, contenu_commentaire, id_visiteur) VALUES ('$id_article', '$commentaire', '$id_visiteur')";
        
        if (mysqli_query($con, $insertQuery)) {
            // Commentaire enregistré avec succès
            echo "<script>alert('Comment successfully stored');</script>";
            echo "<script>window.location.href = 'articles.php?id=$id_article';</script>";
            echo "<script>window.scrollTo({ top: 0, behavior: 'smooth' });</script>";
        } else {
            // Erreur lors de l'insertion du commentaire
            echo "Error: " . mysqli_error($con);
        }
    } else {
        // L'article n'existe pas
        echo "Error: Article with ID $id_article does not exist.";
    }
} else {
    $id_article = $_POST['id_article']; // Récupérer l'ID de l'article depuis le formulaire

    if (!empty($id_article)) {
        echo "<form method='POST' action='articles.php?id=$id_article'>";
    } else {
        echo "<form method='POST' action='articles.php'>";
    }

    echo "<input type='hidden' name='id_article' value='$id_article'>";
    echo "<input type='hidden' name='id_visiteur' value=''>";
    echo "<input type='text' name='commentaire' id='commentaire' placeholder='Ajouter un commentaire'>";
    echo "<input type='submit' value='Poster' onclick='alertMessage()'>";
    echo "</form>";
}

mysqli_close($con);
?>
