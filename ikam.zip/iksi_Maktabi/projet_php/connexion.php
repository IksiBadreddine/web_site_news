<?php
$con=new mysqli('localhost','root','','ikam_db');

/*if($con){
    echo "succes";
}else{
    die(mysqli_error($con));
}
?>*/