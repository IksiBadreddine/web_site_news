<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="layout/styles/art.css">
    <title>IkamArticles.News</title>
</head>
<body>
    <!--header-->
       <!--header-->
<div class="wrapper col1">
    <div id="header"> 
        <div id="logo">
            <h1><a href="http://localhost/projet_php/ikam.php"><i>IKAM.NEWS</i> </a></h1> 
        </div>
        <div id="topnav">
            
            <ul class="ul">
                <li><a href="http://localhost/projet_php/ikam.php">Home</a></li>
                <li><a href="#">Categories</a>
                    <ul>
                        <li><a href="#">1.Politics</a></li>
                        <li><a href="#">2.Sciences</a></li>
                        <li><a href="#">3.Sports</a></li>
                    </ul>
                <li><a href="http://localhost/projet_php/login.php">Login</a></li>
                <li>
                <form action="recherche.php" method="get">
                     <input type="text" name="q" placeholder="Search...">
                      <input type="submit" value="Search">
                </form>
                </li>
            </ul>   
        
        </div>

        <br class="clear" />
    </div>
</div>

      <!--articles-->
   <h1></h1>
   <div class="arti">
   <style>
  div.article_container {
    display:block;
    background-color: #C0B5E3;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-family: Arial, sans-serif;
    color: #1F163B;
    overflow: auto;
  }
  div.article_container h1 {
    color: #1F163B;
   font-size: 24px;
    font-weight: bold;
    ;
    }
    .article-image {
        width: 700px;
        border: 3px solid #1F163B ;
        border-radius: 4px;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    .article-content {
        font-family: Arial, sans-serif;
        font-size: 20px;
        line-height: 1.5;
        color: #333;
    }
    .comment-input {
        width: 85%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-family: Arial, sans-serif;
        font-size: 16px;
        color: #333;
    }
    .comment-button {
        background-color: #1F163B;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-family: Arial, sans-serif;
        font-size: 16px;
        padding: 10px;
        width: 120px;
        margin-left: 5px;
    }
    .comment-button:hover{
        background-color: #2F2259;
    }
    .comment-section {
        margin-top: 20px;
        padding: 10px;
        background-color: #f5f5f5;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .comment {
        margin-bottom: 10px;
        padding: 5px;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .comment-content {
        font-family: Arial, sans-serif;
        font-size: 14px;
        color: #333;
    }

    .comment-username {
        font-weight: bold;
        color: #666;
    }
</style>
    <div class="article_container">
   <?php
require 'connexion.php';
session_start();
if (isset($_GET['id'])) {
    $articleId = $_GET['id'];
    
    $requeteArticle = "SELECT * FROM articles WHERE id_article = $articleId";
    $queryArticle = mysqli_query($con, $requeteArticle);
    $article= mysqli_fetch_assoc($queryArticle);
    
    if ($article) {
        echo "<h1>" . $article['titre_article'] . "</h1>";
        echo "<img src='pics/" . $article['image_article'] . "' class='article-image'>";
        echo "<div class='article-content'>" . $article['contenu_article'] . "</div>";

        $requeteCommentaires = "SELECT * FROM commentaires WHERE id_article = $articleId";
        $queryCommentaires = mysqli_query($con, $requeteCommentaires);
        
        
        
        // Formulaire pour ajouter un commentaire
        echo "<h2>Ajouter un commentaire</h2>";
        
        // Vérifier si la variable de session existe et n'est pas vide
        if (isset($_SESSION['id_visiteur']) && !empty($_SESSION['id_visiteur'])) {
            $id_visiteur = $_SESSION['id_visiteur'];
            
            echo "<form method='POST' action='traitement_commentaire.php'>";
            echo "<input type='hidden' name='id_article' value='$articleId'>";
            echo "<input type='hidden' name='id_visiteur' value='$id_visiteur'>";
            echo "<input type='text' name='commentaire' id='commentaire' class='comment-input' placeholder='Ajouter un commentaire'>";
            echo "<input type='submit' value='Poster' class='comment-button' onclick='return checkCommentaire()'>";
            echo "</form>";
        } else {
            echo "<form method='POST' action='login.php'>";
            echo "<input type='hidden' name='id_article' value='$articleId'>";
            echo "<input type='hidden' name='id_visiteur' value=''>";
            echo "<input type='text' name='commentaire' id='commentaire' class='comment-input' placeholder='Ajouter un commentaire'>";
            echo "<input type='submit' value='Poster' class='comment-button' onclick='alertMessage()'>";
            echo "</form>";
        }
        
        // Affichage des commentaires
            echo "<h2>Commentaires</h2>";
            
            if (mysqli_num_rows($queryCommentaires) > 0) {
                echo "<div class='comment-section'>";
                while ($rowsCommentaires = mysqli_fetch_assoc($queryCommentaires)) {
                    echo "<div class='comment'>";
                    // Requête pour récupérer le nom d'utilisateur associé au commentaire
                    $id_vis = "SELECT username FROM visiteurs WHERE id_visiteur = " . $rowsCommentaires['id_visiteur'];
                    $queryVisiteur = mysqli_query($con, $id_vis);
                    
                    if ($queryVisiteur && mysqli_num_rows($queryVisiteur) > 0) {
                        $rowVisiteur = mysqli_fetch_assoc($queryVisiteur);
                        echo "<span class='comment-username'>Username: " . $rowVisiteur["username"] . "</span><br>";
                        echo "<p class='comment-content'>" . $rowsCommentaires['contenu_commentaire'] . "</p>";
                        
                    } else {
                        echo "<span class='comment-username'>Username: Non trouvé</span><br>";
                        echo "<p class='comment-content'>" . $rowsCommentaires['contenu_commentaire'] . "</p>";
                        
                    }
                    echo "</div>";
                }
                echo "</div>";
            } else {
                echo "Aucun commentaire pour cet article.";
            }

    } else {
        echo "Article non trouvé.";
    }
} else {
    echo "Aucun article spécifié.";
}
?>
</div>
<script>
   /* function checkCommentaire() {
        // Check if the session variable is empty
        var id_visiteur = "<?php echo isset($_SESSION['id_visiteur']) ? $_SESSION['id_visiteur'] : ''; ?>";
        
       /* if (id_visiteur === '') {
            // Display an alert if the session variable is empty
            
         
            return false; // Prevent form submission
        }*/
  //  }
    
    function alertMessage() {
        alert("Vous devez vous inscrire pour pouvoir commenter.");
        window.location.href ="http://localhost/projet_php/login.php";
       // Replace with the URL of the current page
        return false; // Prevent form submission
    }
</script>










    </div>
    

<!----footer--->
<footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>About</h3>
                <p>IKAM.NEWS Website is an online platform dedicated to providing the latest news and information in various fields.</p>
            </div>
            <div class="footer-section">
                <h3>Links</h3>
                <ul class="footer-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Categories</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <ul class="footer-contact">
                    <li><i class="fas fa-envelope"></i>Ikam49@gmail.com</li>
                    <li><i class="fas fa-phone"></i>05-22-00-00-00</li>
                    <li><i class="fas fa-map-marker"></i> Morocco-Safi</li>
                </ul>
            </div>
        </div>
        
    </footer>

    <!--footer
    <div class="footer">
        <div class="Categorie">
                <h2>Categories:</h2>
                    <div class="cat">
                        <ul>
                            <li>Sports</li>
                            <li>Business</li>
                            <li>Technology</li>
                        </ul>
                    </div>
        </div>
        <div class="ContactUs">
            <h2>Contact Us:</h2>
            <div class="contact">
                <ul>
                    <li>Phone: 05-22-00-00-00</li>
                    <li>Email: Ikam49@gmail.com</li>
                    <li>Adress: Morocco-Safi</li>
                </ul>
            </div>
            <div class="icons">
                <i class="fab fa-facebook"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-youtube"></i>
                <i class="far fa-envelope"></i>
            </div>

        </div>
        <div class="AboutUs">
            <h2>About Us:</h2>
            
        </div>
    </div>-->
</body>
</html>