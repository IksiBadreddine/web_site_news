<?php
    require 'connexion.php';
    
    if(isset($_POST['id_article'])){
        $id = $_POST['id_article'];
        $titre = $_POST['titre_article'];
        $contenu = $_POST['contenu_article'];
        
        $sql = "UPDATE articles SET titre_article = '$titre', contenu_article = '$contenu' WHERE id_article = '$id'";
        $query = mysqli_query($con, $sql);
        
        if($query){
            header("Location: http://localhost/projet_php/admin.php");
        } else {
            echo "Échec de la modification";
        }
    }
    elseif(isset($_POST['id_commentaire'])){
        $id = $_POST['id_commentaire'];
        $contenu = $_POST['contenu_commentaire'];
        
        $sql = "UPDATE commentaires SET contenu_commentaire = '$contenu' WHERE id_commentaire = '$id'";
        $query = mysqli_query($con, $sql);
        
        if($query){
            header("Location: http://localhost/projet_php/admin.php");
        } else {
            echo "Échec de la modification";
        }
    }
    elseif(isset($_POST['admin_username'])){
        $admin_username = $_POST['admin_username'];
        $nom = $_POST['nom_admin'];
        $prenom = $_POST['prenom_admin'];
        $email = $_POST['email_admin'];
        $mdp = $_POST['mdp_admin'];
        
        $sql = "UPDATE admins SET admin_username = '$admin_username', nom_admin = '$nom', prenom_admin = '$prenom', email_admin = '$email', mdp_admin = '$mdp' WHERE admin_username = '$admin_username'";
        $query = mysqli_query($con, $sql);
        
        if($query){

            header("Location: http://localhost/projet_php/admin.php");
        } else {
            echo "Échec de la modification";
        }
    }
?>
