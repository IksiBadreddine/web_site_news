<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="layout/styles/s.css">
    <title>IkamSignup.News</title>
</head>
<body>
    <!--header-->
<div class="wrapper col1">
    <div id="header"> 
        <div id="logo">
            <h1><a href="#"><i>IKAM.NEWS</i> </a></h1> 
        </div>
        <div id="topnav">
            
            <ul class="ul">
                <li><a href="http://localhost/projet_php/ikam.php">Home</a></li>
                <li><a href="http://localhost/projet_php/login.php">Login</a></li>
            </ul>   
        
        </div>

        <br class="clear" />
    </div>
</div>
    <!--signup-->
    <div class="loginbox">
        <form class="loginform" method="post" action="traitement.php">
            <h2 class="h2">Sign up<h2>
            <label class="labels">First Name</label>
            <input type="name" name="prenom_visiteur" placeholder="Enter your First Name...">
            <label class="labels">Last name</label>
            <input type="name" name="nom_visiteur" placeholder="Enter your Last Name...">
            <label class="labels">username</label>
            <input type="name" name="username" placeholder="Enter your unique username...">
            <label class="labels">Email</label>
            <input type="email" name="email_visiteur" placeholder="Enter your Email...">
            <label class="labels">Password</label>
            <input type="Password" name="mdp_visiteur" placeholder="Enter your Password...">
            <button type="submit">sign up</button>
        </form> 
        <div class="signin">
            <p>Already have an account? <a class="lien" href="http://localhost/projet_php/login.php">LogIn here!</a></p>
        </div>
    </div>
   <!----footer--->
<footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>About</h3>
                <p>IKAM.NEWS Website is an online platform dedicated to providing the latest news and information in various fields.</p>
            </div>
            <div class="footer-section">
                <h3>Links</h3>
                <ul class="footer-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Categories</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <ul class="footer-contact">
                    <li><i class="fas fa-envelope"></i>Ikam49@gmail.com</li>
                    <li><i class="fas fa-phone"></i>05-22-00-00-00</li>
                    <li><i class="fas fa-map-marker"></i> Morocco-Safi</li>
                </ul>
            </div>
        </div>
        
    </footer>
</body>
</html>
