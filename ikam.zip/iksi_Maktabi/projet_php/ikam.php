<!DOCTYPE html>
<html lang="en">
<head>
    <title>Ikam.News</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="layout/styles/mak.css" type="text/css" />
    <script type="text/javascript" src="layout/scripts/jquery.min.js"></script>
    <script type="text/javascript" src="layout/scripts/jquery.jcarousel.pack.js"></script>
    <script type="text/javascript" src="layout/scripts/jquery.jcarousel.setup.js"></script>
    <style>
    


/* Styles pour les icônes */
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css');

    </style>
    
</head>
<body id="top">
    <!--header-->
<div class="wrapper col1">
    <div id="header"> 
        <div id="logo">
            <h1><a href="#"><i>IKAM.NEWS</i> </a></h1> 
        </div>
        <div id="topnav">
            
            <ul class="ul">
                <li><a href="#">Home</a></li>
                <li><a href="#">Categories</a>
                    <ul>
                        <li><a href="#politics">1.Politics</a></li>
                        <li><a href="#sciences">2.Sciences</a></li>
                        <li><a href="#sports">3.Sports</a></li>
                    </ul>
                <li><a href="http://localhost/projet_php/login.php">Login</a></li>
                <li>
                <form action="recherche.php" method="get">
                     <input type="text" name="q" placeholder="Search...">
                      <input type="submit" value="Search">
                </form>
                </li>
                <li><!-- Bouton de déconnexion -->
                    <form method="POST" action="logout.php">
                    <input type="submit" name="logout" value="LogOut    ">
                </form>
                </li>
            </ul>   
        
        </div>

        <br class="clear" />
    </div>
</div>
<div class="wrapper col2">
  <div id="featured_slide">
    <div id="featured_content">
      <ul>
        <li><img src="pics/1.jpg" alt="" />
          <div class="floater">
            <h2>Politics</h2>
            <p>Politics is the activities, actions, and policies used by individuals, groups, or governments to gain and hold power or influence over a society. It involves the distribution of resources, decision-making processes, and the exercise of authority in order to shape and govern the policies and affairs of a community, state, or nation.</a>.</p>
            
          </div>
        </li>
        <li><img src="pics/2.png" alt="" />
          <div class="floater">
            <h2>Sciences</h2>
            <p>Sciences, also known as the scientific disciplines or the scientific method, refer to systematic and organized knowledge acquisition about the natural and social world through observation, experimentation, and analysis. Sciences aim to understand and explain the phenomena and processes that occur in the universe, uncovering patterns, laws, and principles that govern them.</p>
            
          </div>
        </li>
        <li><img src="pics/3.jpg" alt="" />
          <div class="floater">
            <h2>Sport</h2>
            <p>Sports refer to physical activities or games that involve skill, competition, and physical exertion. They are typically governed by a set of rules or regulations and are often played for entertainment, recreation, and sometimes for professional or competitive purposes. Sports can be individual or team-based and can take various forms, including but not limited to athletics, ball games, combat sports, water sports, and winter sports.</p>
            
          </div>
        </li>
      </ul>
    </div>
    <a href="javascript:void(0);" id="featured-item-prev"><img src="layout/images/ar.png" alt="" /></a> <a href="javascript:void(0);" id="featured-item-next"><img src="layout/images/al.png" alt="" /></a> </div>
</div>
 


<div class="page2">
    <!--sport-->
        <div class="news" id="politics">
            <div class="title">
                <h2>Politic News</h2>
            </div>
            <div class="newsBox">
            <?php
            require 'connexion.php';

            echo "<br class='clear' />";
            $requete="SELECT *from articles where id_categorie= 1 ORDER BY id_article DESC ";
            $query=mysqli_query($con,$requete);
            while($rows=mysqli_fetch_assoc($query)){
                echo "<div class='b'>";
                    echo "<li>";
                        echo "<img src='pics/".$rows['image_article']."'>"; 
                        echo "<h2 ><a href='articles.php?id=" . $rows['id_article'] . "'>" . $rows['titre_article'] . "</a></h2>";
                    echo "</li>";
                echo "</div>";
            }
            ?>
            </div>
        </div>
        <!--sport-->
        <div class="news" id="sciences">
            <div class="title">
                <h2>Science News</h2>
            </div>
            <div class="newsBox">
            <?php
            require 'connexion.php';

            echo "<br class='clear' />";
            $requete="SELECT *from articles where id_categorie= 2 ORDER BY id_article DESC ";
            $query=mysqli_query($con,$requete);
            while($rows=mysqli_fetch_assoc($query)){
                echo "<div class='b'>";
                    echo "<li>";
                        echo "<img src='pics/".$rows['image_article']."'>"; 
                        echo "<h2 ><a href='articles.php?id=" . $rows['id_article'] . "'>" . $rows['titre_article'] . "</a></h2>";
                    echo "</li>";
                echo "</div>";
            }
            ?>
            </div>
        </div>
        <!--sport-->
        <div class="news" id="sports">
            <div class="title">
                <h2>Sport News</h2>
            </div>
            <div class="newsBox">
            <?php
            require 'connexion.php';

            echo "<br class='clear' />";
            $requete="SELECT *from articles where id_categorie= 3 ORDER BY id_article DESC ";
            $query=mysqli_query($con,$requete);
            while($rows=mysqli_fetch_assoc($query)){
                echo "<div class='b'>";
                    echo "<li>";
                        echo "<img src='pics/".$rows['image_article']."'>"; 
                        echo "<h2 ><a href='articles.php?id=" . $rows['id_article'] . "'>" . $rows['titre_article'] . "</a></h2>";
                    echo "</li>";
                echo "</div>";
            }
            ?>
            </div>
        </div>
    </div>





 
<footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>About</h3>
                <p>IKAM.NEWS Website is an online platform dedicated to providing the latest news and information in various fields.</p>
            </div>
            <div class="footer-section">
                <h3>Links</h3>
                <ul class="footer-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Categories</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <ul class="footer-contact">
                    <li><i class="fas fa-envelope"></i>Ikam49@gmail.com</li>
                    <li><i class="fas fa-phone"></i>05-22-00-00-00</li>
                    <li><i class="fas fa-map-marker"></i> Morocco-Safi</li>
                </ul>
            </div>
        </div>
        
    </footer>


    
    <script src="index.js"></script>
</body>
</html>