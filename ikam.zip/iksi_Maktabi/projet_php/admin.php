<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="layout/styles/admm.css">
    <title>IkamAdmins.News</title>
</head>
<body>
    <!--header-->
<div class="wrapper col1">
    <div id="header"> 
        <div id="logo">
            <h1><a href="#"><i>IKAM.NEWS</i> </a></h1> 
        </div>
        <div id="topnav">
            
            <ul class="ul">
                <li><a href="http://localhost/projet_php/ikam.php">Home</a></li>
                <li><a href="#articles">Articles</a></li>
                <li><a href="#comments">Commentaires</a></li>
                <li><a href="#Admins">Administrateurs</a></li>
                
                <li><a href="http://localhost/projet_php/ikam.php">Logout</a></li>
            </ul>   
        
        </div>

        <br class="clear" />
    </div>
</div>

    <!-- Gestion des articles -->
<div class="tableaux" id="articles">
    <h1 class="title" >Articles</h1>
    
        <div class="table">
            <table class="box" border="1" width="100%" >
        <tr>
            <th>id_article</th>
            <th>titre_article</th>
            <th>contenu_article</th>
            
            
        </tr>
        <?php
        require 'connexion.php';
        $requete = "SELECT id_article, titre_article, contenu_article, image_article FROM articles ";
        $query = mysqli_query($con, $requete);
        while ($rows = mysqli_fetch_assoc($query)) {
            $id = $rows['id_article'];
            
            echo "<tr>";
            
            echo "<td >" . $rows['id_article'] . "</td>";
            
            echo "<td>" . $rows['titre_article'] . "</td>";
            
            echo "<td>" . $rows['contenu_article'] . "</td>";
            
            echo "<td><th><button class='bn'><a class='bna'href='delete.php?id_article=" . $id . "'>Supprimer</a></button></th></td>";
            echo "<td><th>   <button class='edit'><a class='edit' href='modifier.php?id_article=" . $id . "'>Edit </a>
            <svg class='svg' viewBox='0 0 512 512'>
              <path d='M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z'></path></svg>
          </button>
          
      </th></td>";
            echo "</tr>";
        }
        ?>
    </table>
        </div>
        <script>
        function redirectToArticlePage() {
            window.location.href = "ajouter_article.php";
        }
    </script>
    <button class="bouton" type="button" onclick="redirectToArticlePage()">Ajouter un article</button>
</div>

<!-- Gestion des commentaires -->
<div class="tableaux" id="comments">
    <h1 class="title">Commentaires</h1>
    <div class="table">
        <table class="box" border="1" width="60%">
        <tr>
            <th>id_commentaire</th>
            <th>contenu_commentaire</th>
            <th>id_article</th>
            <th>id_visiteur</th>
        </tr>
        <?php
        require 'connexion.php';
        $requete = "SELECT * FROM commentaires";
        $query = mysqli_query($con, $requete);
        while ($rows = mysqli_fetch_assoc($query)) {
            $id = $rows['id_commentaire'];
            echo "<tr>";
            echo "<td>" . $rows['id_commentaire'] . "</td>";
            echo "<td>" . $rows['contenu_commentaire'] . "</td>";
            echo "<td>" . $rows['id_article'] . "</td>";
            echo "<td>" . $rows['id_visiteur'] . "</td>";
            echo "<td><th><button class='bn'><a class='bna'href='delete.php?id_commentaire=" . $id . "'>Supprimer</a></button></th></td>";
            echo "</tr>";
        }
        ?>
    </table>
    </div>
    
</div>

<!-- Gestion des admins -->
<div class="tableaux" id="Admins">
    <h1 class="title">Administrateurs</h1>  
     
    <div class="table">
        
        
        <table class="box" border="1" width="60%">
        <tr>
            <th>admin_username</th>
            <th>Nom_admin</th>
            <th>Prenom_admin</th>
            <th>Email_admin</th>
            <th>Mots de passe</th>
        </tr>
        <?php
        require 'connexion.php';
        $requete = "SELECT * FROM admins";
        $query = mysqli_query($con, $requete);
        while ($rows = mysqli_fetch_assoc($query)) {
            $id = $rows['admin_username'];
            echo "<tr>";
            echo "<td>" . $rows['admin_username'] . "</td>";
            echo "<td>" . $rows['nom_admin'] . "</td>";
            echo "<td>" . $rows['prenom_admin'] . "</td>";
            echo "<td>" . $rows['email_admin'] . "</td>";
            echo "<td>" . $rows['mdp_admin'] . "</td>";
            echo "<td><th><button class='bn'><a class='bna'href='delete.php?admin_username=" . $id . "'>Supprimer</a></button></th></td>";
            echo "<td><th>   <button class='edit'><a class='edit' href='modifier.php?admin_username=" . $id . "'>Edit </a>
            <svg class='svg' viewBox='0 0 512 512'>
              <path d='M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z'></path></svg>
          </button>
      
      </th></td>";
            echo "</tr>";
        }
        ?>
    </table>
    </div>
    <script>
        function redirectToAdminPage() {
            window.location.href = "ajouter_admin.php";
        }
        </script>
    <button class="bouton" type="button" onclick="redirectToAdminPage()">Ajouter un admin</button>

    
</div>

    </table>
    </div>
    

    
</body>
</html>