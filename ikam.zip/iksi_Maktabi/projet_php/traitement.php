<?php
$prenom_visiteur = $_POST['prenom_visiteur'];
$nom_visiteur = $_POST['nom_visiteur'];
$username=$_POST['username'];
$email_visiteur = $_POST['email_visiteur'];
$mdp_visiteur = $_POST['mdp_visiteur'];
//$unique="SELECT COUNT(*) FROM visiteurs WHERE username = '$username'";
// Vérifier si les champs ne sont pas vides

if (!empty($prenom_visiteur) && !empty($nom_visiteur) && !empty($username) && !empty($email_visiteur) && !empty($mdp_visiteur)) {
    require 'connexion.php';
    /*if ($unique > 0 ) {
        echo '<script>alert("Veuillez choisir un autre username car il exist deja.");window.location.href = "http://localhost/projet_php/signup.php";</script>';
        exit();
    }else{*/
    $requete = "INSERT INTO visiteurs(nom_visiteur, prenom_visiteur, username, email_visiteur, mdp_visiteur) 
            VALUES ('$nom_visiteur', '$prenom_visiteur','$username', '$email_visiteur', '$mdp_visiteur')";

    $result = mysqli_query($con, $requete);

    if (mysqli_affected_rows($con) > 0) {
    
        echo '<script>alert("Insertion réussie."); window.location.href ="http://localhost/projet_php/login.php";</script>';
    } else {
        echo '<script>alert("L\'insertion a échoué.");</script>';
    }
    }
 else {
    echo '<script>alert("Veuillez remplir tous les champs.");window.location.href = "http://localhost/projet_php/signup.php";</script>';
}





?>

