<?php
session_start();

// Déconnexion (logout)
if (isset($_POST['logout'])) {
    // Réinitialiser la variable de session id_visiteur
    $_SESSION['id_visiteur'] = null;
    // Rediriger vers la page de connexion ou une autre page de votre choix
    header("Location: login.php");
    exit();
}
?>