
<?php
require 'connexion.php';
if (isset($_GET['id_article'])) {
    $id = $_GET['id_article'];
    // Récupérer les informations de l'article à modifier
    $sql = "SELECT * FROM articles WHERE id_article = '$id'";
    $query = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($query);

    // Récupérer les administrateurs
    $sqlAdmins = "SELECT admin_username FROM admins";
    $queryAdmins = mysqli_query($con, $sqlAdmins);
    $admins = mysqli_fetch_all($queryAdmins, MYSQLI_ASSOC);

    // Récupérer les catégories
    $sqlCategories = "SELECT * FROM categorie";
    $queryCategories = mysqli_query($con, $sqlCategories);
    $categories = mysqli_fetch_all($queryCategories, MYSQLI_ASSOC);
?>

    <div class="form-container">
        <form method="POST" action="traitement_modifier.php" enctype="multipart/form-data">
            <input type="hidden" name="id_article" value="<?php echo $id; ?>">
            <div class="input-group">
                <label for="titre">Titre</label>
                <input type="text" name="titre_article" id="titre" value="<?php echo $row['titre_article']; ?>">
            </div>
            <div class="input-group">
                <label for="contenu">Contenu</label>
                <textarea name="contenu_article" id="contenu"><?php echo $row['contenu_article']; ?></textarea>
            </div>
            <div class="input-group">
                <label for="editeur">Administrateur</label>
                <select name="editeur" id="editeur">
                    <?php foreach ($admins as $admin) {
                        $selected = ($admin['admin_username'] == $row['editeur']) ? 'selected' : '';
                        echo "<option value='" . $admin['admin_username'] . "' " . $selected . ">" . $admin['admin_username'] . "</option>";
                    } ?>
                </select>
            </div>
            <div class="input-group">
                <label for="categorie">Catégorie</label>
                <select name="categorie" id="categorie">
                    <?php foreach ($categories as $categorie) {
                        $selected = ($categorie['id_categorie'] == $row['nom_categorie']) ? 'selected' : '';
                        echo "<option value='" . $categorie['id_categorie'] . "' " . $selected . ">" . $categorie['nom_categorie'] . "</option>";
                    } ?>
                </select>
            </div>
            <div class="input-group">
                <label for="image">Importer image</label>
                <input type="file" name="imageToUpload" id="image">
            </div>
            <div class="input-group">
                <input type="submit" value="Modifier">
            </div>
        </form>
    </div>

<?php
}  elseif (isset($_GET['admin_username'])) {
    $id = $_GET['admin_username'];
    // Récupérer les informations de l'administrateur à modifier
    $sql = "SELECT * FROM admins WHERE admin_username = '$id'";
    $query = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($query);
?>

    <div class="form-container">
        <form method="POST" action="traitement_modifier.php">
            
            <input type="hidden" name="id_admin" value="<?php echo $id; ?>">
            <label for="username">Username</label>
            <input type="text" name="admin_username" value="<?php echo $row['admin_username']; ?>"><br>
            <label for="nom">Nom</label>
            <input type="text" name="nom_admin" value="<?php echo $row['nom_admin']; ?>"><br>
            <label for="prenom">Prenom</label>
            <input type="text" name="prenom_admin" value="<?php echo $row['prenom_admin']; ?>"><br>
            <label for="email">Email</label>
            <input type="text" name="email_admin" value="<?php echo $row['email_admin']; ?>"><br>
            <label for="tmdp">Password</label>
            <input type="text" name="mdp_admin" value="<?php echo $row['mdp_admin']; ?>"><br>
            <input type="submit" value="Modifier">
        </form>
    </div>

<?php
}
?>
<style>
    .form-container {
        background-color: #C0B5E3;
        padding: 20px;
        border-radius: 5px;
        
    }

    .form-container label {
        color: #2F2259;
        font-weight: bold;
    }

    .form-container input[type="text"],
    .form-container textarea,
    .form-container select {
        background-color: white;
        color: black;
        border: #2F2259 solid 1px;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 10px;

    }

    .form-container input[type="file"] {
        color: #2F2259;
    }

    .form-container input[type="submit"] {
        background-color: #2F2259;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
    }

    .form-container input[type="submit"]:hover {
        background-color: #2F2259;
    }
</style>


