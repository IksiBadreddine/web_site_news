<?php
include 'connexion.php';
if (isset($_POST['Enregistrer'])) {
    $titre_article = $_POST['titre_article']; 
    $contenu_article = $_POST['contenu_article']; 
    $categorie = $_POST['categorie'];
    $editeur = $_POST['editeur'];

    if(isset($_FILES['imageToUpload'])){
        move_uploaded_file($_FILES['imageToUpload']['tmp_name'], "images/". $_FILES['imageToUpload']['name']);
        $image = $_FILES['imageToUpload']['name'];
    } else {
        echo "Image not found!";
        $image = "";
    }

    $sql = 'INSERT INTO articles(titre_article, contenu_article, admin_username, id_categorie, image_article) 
            VALUES (?, ?, ?, ?, ?)';

    $statement = mysqli_prepare($con, $sql);
    
    if (!$statement) {
        echo "Erreur de préparation de la requête : " . mysqli_error($con);
        exit();
    }
    
    mysqli_stmt_bind_param($statement, "sssss", $titre_article, $contenu_article, $editeur, $categorie, $image);

    if (mysqli_stmt_execute($statement)) {
        echo "Article enregistré avec succès!";
    } else {
        echo "Erreur lors de l'exécution de la requête : " . mysqli_stmt_error($statement);
    }

    mysqli_stmt_close($statement);
}

mysqli_close($con);
?>