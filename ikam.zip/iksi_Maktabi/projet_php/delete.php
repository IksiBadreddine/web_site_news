<?php
    require 'connexion.php';
    if(isset($_GET['id_article'])){
        $id = $_GET['id_article'];
        $sql = "DELETE FROM articles WHERE id_article = '$id'";
        $query = mysqli_query($con, $sql);
        if($query){
            $message = "Suppression réussie.";
            echo "<script>alert('" . $message . "'); window.location.href ='http://localhost/projet_php/admin.php';</script>";
        } else {
            echo "Échec de la suppression";
        }
    }
    elseif(isset($_GET['id_commentaire'])){
        $id = $_GET['id_commentaire'];
        $sql = "DELETE FROM commentaires WHERE id_commentaire = '$id'";
        $query = mysqli_query($con, $sql);
        if($query){
            $message = "Suppression réussie.";
            echo "<script>alert('" . $message . "'); window.location.href ='http://localhost/projet_php/admin.php';</script>";
        } else {
            echo "Échec de la suppression";
        }
    }
    elseif(isset($_GET['admin_username'])){
        $id = $_GET['admin_username'];
        $sql = "DELETE FROM admins WHERE admin_username = '$id'";
        $query = mysqli_query($con, $sql);
        if($query){
            $message = "Suppression réussie.";
            echo "<script>alert('" . $message . "'); window.location.href ='http://localhost/projet_php/admin.php';</script>";
        } else {
            echo "Échec de la suppression";
        }
    }
?>
