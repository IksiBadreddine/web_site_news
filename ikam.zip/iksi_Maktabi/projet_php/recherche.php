
<?php

$query = $_GET['q'];
require 'connexion.php';

// Prepare the search query to find articles that match the search query in the article title, content, and HTML code
$searchQuery = "SELECT * FROM articles WHERE titre_article LIKE '%$query%' OR contenu_article LIKE '%$query%' OR contenu_article LIKE '%$query%'";
$searchResult = mysqli_query($con, $searchQuery);

// Check if any results were found
if (mysqli_num_rows($searchResult) > 0) {
    // Loop through the search results and display them
    while ($row = mysqli_fetch_assoc($searchResult)) {
        echo "<h1>" . $row['titre_article'] . "</h1>";
        echo "<img src='images/" . $row['image_article'] . "'>";
        echo "<p>" . $row['contenu_article'] . "</p>";
        // ... Display other article details as needed
    }
} else {
    echo "No results found.";
}

// Close the database connection
mysqli_close($con);
?>